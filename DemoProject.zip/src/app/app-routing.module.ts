import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DemoComponentComponent } from './components/demo-component/demo-component.component';
import { DataPassingComponent } from './components/data-passing/data-passing.component';
import { DataBindingComponent } from './components/data-binding/data-binding.component';

const routes: Routes = [
  {
    path:'demo',component:DemoComponentComponent
  },
  {
    path:'dataSharing',component:DataPassingComponent
  },
  {
    path:'data-binding',component:DataBindingComponent
  },
  {
    path:'', redirectTo:'demo',pathMatch:'full'
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
