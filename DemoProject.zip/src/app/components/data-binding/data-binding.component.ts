import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-binding',
  templateUrl: './data-binding.component.html',
  styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent implements OnInit {

  constructor() { }

  screenTitle = 'Data Binding';
  userName:any;

  ngOnInit(): void {
  }

  enterUsername(event:any){
    console.log("username event",event.target.value);
    this.userName = event.target.value;
  }

}
